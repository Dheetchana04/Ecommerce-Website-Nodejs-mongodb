let all = document.querySelector("#all");
let cosmetics = document.querySelector("#cosmetics");
let appliances = document.querySelector("#appliances");
let clothes = document.querySelector("#clothes");
let main = document.querySelector("main");
let search_bar = document.querySelector("header input");
let myproducts = document.querySelector("#myproducts");
let orders = document.querySelector("#orders");
let cart = document.querySelector("#cart");

let type = JSON.parse(localStorage.getItem("type"));

if (type) {
  orders.classList.remove("hide");
  cart.classList.remove("hide");
}
if (type == "seller") {
  myproducts.classList.remove("hide");
}

function load_items(arr) {
  main.innerHTML = arr
    .map((obj) => {
      return `
        <section id="${obj._id}">
        <div class="img">
        <img src="${obj.imgLink}" alt="" />
        <p class="hide">${obj.description}</p>
        </div>
        <div>
            <p>${obj.name}</p>
            <p>Rs ${obj.price}</p>
            <p>stock : ${obj.stock}</p>
        </div>
        <button>Add <i class="fa-solid fa-cart-shopping"></i></button>
      </section>
        `;
    })
    .join("");
}

function render(url, body) {
  fetch(`/${url}`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(body),
  })
    .then((data) => {
      return data.json();
    })
    .then((data) => {
      load_items(data);
    })
    .then(() => {
      add_item();
    })
    .then(() => {
      let img_div = document.querySelectorAll(".img");
      img_div.forEach((img) => {
        img.addEventListener("mouseenter", () => {
          img.children[1].classList.remove("hide");
        });
        img.addEventListener("mouseleave", () => {
          img.children[1].classList.add("hide");
        });
      });
    });
}

function default_items() {
  render("items");
}

default_items();

all.addEventListener("click", () => {
  location.reload();
});

cosmetics.addEventListener("click", () => {
  render("cosmetics");
});

appliances.addEventListener("click", () => {
  render("appliances");
});

clothes.addEventListener("click", () => {
  render("clothes");
});

search_bar.addEventListener("keyup", () => {
  let body = {
    value: search_bar.value,
  };
  render("search", body);
});

function add_item() {
  let buttons = document.querySelectorAll("main button");
  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      let stock = button.parentElement.children[1].children[2].innerHTML.split(" ")[2]
      fetch("/cart_count", {
        method: "POST",
        headers: {
          "content-type": "application/json",
        },
        body: JSON.stringify({
            id : button.parentElement.getAttribute("id")
        }),
      }).then((data)=>{
        return data.json();
      })
      .then((count)=>{
        
        if (count < stock) {
            fetch("/item", {
                method: "POST",
                headers: {
                  "content-type": "application/json",
                },
                body: JSON.stringify({
                  id: button.parentElement.getAttribute("id"),
                }),
              })
                .then((data) => {
                  return data.json();
                })
                .then((data) => {
                  fetch("/add", {
                    method: "PUT",
                    headers: {
                      "content-type": "application/json",
                    },
                    body: JSON.stringify(data),
                  })
                    .then((data) => {
                      return data.json();
                    })
                    .then((data) => {
                      if (data == null) {
                        location.href = "/signin";
                      }
                    });
                });
        }
      })
    });
  });
}