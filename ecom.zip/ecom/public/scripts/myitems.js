let main = document.querySelector("main")
let add_button = document.querySelector("#add")
let form = document.querySelector("header section")
let submit = document.querySelector("header section button")

add_button.addEventListener("click",()=>{
    form.classList.toggle("hide")
})

function load_items (arr) {
    main.innerHTML = arr.map((obj)=>{
        return `
        <section class="${obj._id}">
        <img src="${obj.imgLink}" alt="" />
        <div>
            <p>${obj.name}</p>
            <p>Rs ${obj.price}</p>
        </div>
        <button class="${obj.type}">Remove <i class="fa-solid fa-xmark"></i></button>
      </section>
        `
    }).join("")
}

function render (url,body) {
    fetch(`/${url}`,{
        method : "POST",
        headers : {
            "content-type" : "application/json"
        },
        body : JSON.stringify(body)
    })
    .then((data)=>{
        return data.json()
    })
    .then((data)=>{
        load_items(data)
    })
    .then(()=>{
        delete_item()
    })
}

function default_items () {
    render("myitems")
}

default_items()

function delete_item () {
    let buttons = document.querySelectorAll("main button")
    buttons.forEach((button)=>{
        button.addEventListener("click",()=>{        
            fetch("/myitem",{
                method : "DELETE",
                headers : {
                    "content-type" : "application/json"
                },
                body : JSON.stringify({
                    name : button.parentElement.children[1].children[0].innerHTML,
                    price : button.parentElement.children[1].children[1].innerHTML.split(" ")[1],
                    imgLink : button.parentElement.children[0].getAttribute("src"),
                    type : button.className,
                    _id : button.parentElement.className
                })
            })
            .then(()=>{
                location.reload()
            })
        })
    })
}

submit.addEventListener("click",()=>{
    let inputs = document.querySelectorAll("header section input")
    let type = document.querySelector("select")
    let description = document.querySelector("textarea")
    fetch("/myitem",{
        method : "POST",
        headers : {
            "content-type" : "application/json"
        },
        body : JSON.stringify({
            name : inputs[0].value,
            price : inputs[1].value,
            imgLink : inputs[3].files[0].name,
            type : type.value,
            description : description.value,
            stock : inputs[2].value,
        })
    })
    .then(()=>{
        location.reload()
    })
})