let inputs = document.querySelectorAll("input");
let error = document.querySelector("#error");
let button = document.querySelector("button");
let type = document.querySelector("select");

inputs.forEach((input) => {
  input.addEventListener("click", () => {
    error.classList.add("hide");
  });
});

function request(url, method, body) {
  fetch(`/${url}`, {
    method: `${method}`,
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify(body),
  }).then((data) => {
    return data.json()
  }).then((data)=>{
    if (data != "") {
      localStorage.setItem("type",JSON.stringify(data.type))
        location.href = data.to
    }
    else{
        error.classList.remove("hide")
    }
  })
}

button.addEventListener("click", () => {
  let body;
  if (button.getAttribute("id") == "signin") {
    body = {
      email: inputs[0].value,
      password: inputs[1].value,
    };
    request("signin", "POST", body);
  } else if (button.getAttribute("id") == "signup") {
    body = {
      email: inputs[0].value,
      password: inputs[1].value,
      type : type.value,
      address : inputs[2].value
    };
    request("signup", "POST", body);
  }
});
