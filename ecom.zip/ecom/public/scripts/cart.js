let main = document.querySelector("main")
let total_p = document.querySelector("#total")
let checkout = document.querySelector("#checkout")
let clear_button = document.querySelector("#clear")

function load_items (arr) {
    main.innerHTML = arr.map((obj)=>{
        return `
        <section id="${obj._id}">
        <img src="${obj.imgLink}" alt="" />
        <div>
            <p>${obj.name}</p>
            <p>Rs ${obj.price}</p>
        </div>
        <button>Remove <i class="fa-solid fa-trash"></i></button>
      </section>
        `
    }).join("")
}

function total (data) {
    let total_amount = 0;
    data.forEach((obj)=>{
        total_amount = total_amount + Number(obj.price)
    })
    total_p.innerHTML = "Rs " + total_amount
}

function clear () {
    fetch("/clear",{
        method : "PUT",
        headers : {
            "content-type" : "application/json"
        }
    })
    location.reload()
}

function render (url) {
    fetch(`/${url}`,{
        method : "POST",
        headers : {
            "content-type" : "application/json"
        }
    })
    .then((data)=>{
        return data.json()
    })
    .then((data)=>{
        load_items(data)
        total(data)
    })
    .then(()=>{
        remove_item()
    })
}

function default_items () {
    render("cart")
}

default_items()

function remove_item () {
    let buttons = document.querySelectorAll("main button")
    buttons.forEach((button)=>{
        button.addEventListener("click",()=>{
            fetch("/item",{
                method : "POST",
                headers : {
                    "content-type" : "application/json"
                },
                body : JSON.stringify({
                    id : button.parentElement.getAttribute("id")
                })
            })
            .then((data)=>{
                return data.json()
            })
            .then((data)=>{
                fetch("/remove",{
                    method : "PUT",
                    headers : {
                        "content-type" : "application/json"
                    },
                    body : JSON.stringify(data)
                })
            })
            location.reload()
        })
        })
}

checkout.addEventListener("click",()=>{
    let buttons = document.querySelectorAll("main button")
    buttons.forEach((button)=>{
            fetch("/item",{
                method : "POST",
                headers : {
                    "content-type" : "application/json"
                },
                body : JSON.stringify({
                    id : button.parentElement.getAttribute("id")
                })
            })
            .then((data)=>{
                return data.json()
            })
            .then((data)=>{
                fetch("/order",{
                    method : "PUT",
                    headers : {
                        "content-type" : "application/json"
                    },
                    body : JSON.stringify({
                        item : data
                    })
                })
            })
        })
        setTimeout(()=>{
            clear()
        },1000)
})

clear_button.addEventListener("click",()=>{
    clear()
})