let main = document.querySelector("main")
let returns = document.querySelector("#returns")
let h = document.querySelector("header h3")

function load_items (arr,url) {
    main.innerHTML = arr.map((obj)=>{
        return `
        <section class="${obj._id} ${obj.item._id}">
        <img src="${obj.item.imgLink}" alt="" />
        <div>
            <p>${obj.item.name}</p>
            <p>Rs ${obj.item.price}</p>
        </div>
        ${(url == "orders")?`<button>Return <i class="fa-solid fa-arrow-right"></i></button>`:`<button>Cancel <i class="fa-solid fa-arrow-right"></i></button>`}
      </section>
        `
    }).join("")
}

function render (url) {
    fetch(`/${url}`,{
        method : "POST",
        headers : {
            "content-type" : "application/json"
        }
    })
    .then((data)=>{
        return data.json();
    })
    .then((data)=>{
        load_items(data,url);
    })
    .then(()=>{
        return_item(url)
        if (url == "returns") {
            returns.classList.add("hide")
            h.innerHTML = "My Returns"
        }
    })
}

function default_items () {
    render("orders")
}

default_items()

returns.addEventListener("click",()=>{
    render("returns")
})

function return_item (url) {
    let buttons = document.querySelectorAll("main button")
    buttons.forEach((button)=>{
        button.addEventListener("click",()=>{
            fetch("/item",{
                method : "POST",
                headers : {
                    "content-type" : "application/json"
                },
                body : JSON.stringify({
                    id : button.parentElement.classList.item(1)
                })
            })
            .then((data)=>{
                return data.json()
            })
            .then((data)=>{
                console.log(data);
                
                if(url == "orders") {
                    fetch("/return",{
                        method : "PUT",
                        headers : {
                            "content-type" : "application/json"
                        },
                        body : JSON.stringify({
                            item : data
                        })
                    })
                    .then(()=>{
                        fetch("/update_order",{
                            method : "DELETE",
                            headers : {
                                "content-type" : "application/json"
                            },
                            body : JSON.stringify({
                                id : button.parentElement.classList.item(0)
                            })
                        })
                    })
                }
                else if (url == "returns") {
                    fetch("/order",{
                        method : "PUT",
                        headers : {
                            "content-type" : "application/json"
                        },
                        body : JSON.stringify({
                            item : data
                        })
                    })
                    .then(()=>{
                        fetch("/update_return",{
                            method : "DELETE",
                            headers : {
                                "content-type" : "application/json"
                            },
                            body : JSON.stringify({
                                id : button.parentElement.classList.item(0)
                            })
                        })
                    })
                }
            })
            .then(()=>{
                location.reload()
            })
        })
        })
}