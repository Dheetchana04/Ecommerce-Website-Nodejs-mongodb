let express = require("express");

let bodyParser = require("body-parser");
let cors = require("cors")
require("dotenv").config()
let router = require("./router.js")
let cookie_parser = require("cookie-parser")

let mongoose = require("mongoose");

let server = express();
let port = process.env.PORT
mongoose.connect("mongodb://localhost:27017/ecom");

server.use(cookie_parser())
server.use(bodyParser.json());
server.use(cors());
server.use(express.static("public"));
server.use(router);

server.listen(port, (err) => {
  if (err) {
    console.log(err);
  }
  else{
    console.log(`connected ${port}`);
  }
});
