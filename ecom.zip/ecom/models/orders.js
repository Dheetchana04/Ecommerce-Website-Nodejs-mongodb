let mongoose = require("mongoose")

const orders = new mongoose.Schema({
  item : Object,
  user_id : String,
  address : Object
});

module.exports = mongoose.model('orders', orders);