let mongoose = require("mongoose");
const items = require("./items");

const users = new mongoose.Schema({
  email: String,
  password: String,
  type : String,
  address : String,
  cart: Array,
  items : Array
});

module.exports = mongoose.model("users", users);