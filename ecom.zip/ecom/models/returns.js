let mongoose = require("mongoose")

const returns = new mongoose.Schema({
  item : Object,
  user_id : String,
  address : Object
});

module.exports = mongoose.model('returns', returns);