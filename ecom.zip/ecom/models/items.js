let mongoose = require("mongoose")

const items = new mongoose.Schema({
  name: String,
  price: Number,
  imgLink: String,
  type : String,
  stock : Number,
  description : String
});

module.exports = mongoose.model('items', items)