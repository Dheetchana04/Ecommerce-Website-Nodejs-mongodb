let express = require("express")
let router = express.Router()
let gets = require("./controller/get.js")
let posts = require("./controller/post.js")
let puts = require("./controller/put.js")
let deletes = require("./controller/delete.js")
const multer  = require('multer')
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, '../images')
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname + '-' + Date.now())
    }
  })
  
  const upload = multer({ storage: storage })


router.get("/signin",gets.signin)
router.get("/signup",gets.signup)
router.get("/",gets.home)
router.get("/cart",gets.cart)
router.get("/orders",gets.orders)
router.get("/myitems",gets.myitems)

router.post("/signin",posts.signin)
router.post("/signup",posts.signup)
router.post("/cosmetics",posts.cosmetics)
router.post("/appliances",posts.appliances)
router.post("/clothes",posts.clothes)
router.post("/item",posts.item)
router.post("/items",posts.items)
router.post("/orders",posts.orders)
router.post("/returns",posts.returns)
router.post("/cart",posts.cart)
router.post("/search",posts.search)
router.post("/myitems",posts.myitems)
router.post("/myitem",upload.single("img"),posts.myitem)
router.post("/cart_count",posts.cart_count)

router.put("/add",puts.add)
router.put("/remove",puts.remove)
router.put("/order",puts.order)
router.put("/return",puts.return)
router.put("/clear",puts.clear)

router.delete("/update_order",deletes.update_order)
router.delete("/update_return",deletes.update_return)
router.delete("/myitem",deletes.myitem)

module.exports = router