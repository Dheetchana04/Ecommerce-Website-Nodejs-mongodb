let items = require("../models/items.js");
let users = require("../models/user.js");
let email_validator = require("email-validator");
let orders = require("../models/orders.js");
let returns = require("../models/returns.js");

exports.signup = function (req, res) {
  if (email_validator.validate(req.body.email)) {
    users.findOne({ email: req.body.email }).then((data) => {
      if (data) {
        res.json("");
      } else {
        let user = new users(req.body);
        user.save();
        res.json({
          to : "/signin"
        })
      }
    });
  }
  else{
    res.json("")
  }
}

exports.signin = function (req, res) {
  users
    .findOne({
      email: req.body.email,
      password: req.body.password,
    })
    .then((data) => {
      if (data) {
        res.cookie("id", data._id);
        res.cookie("address", data.address);
        res.json({
          type : data.type,
          to : "/"
        })
      } else {
        res.json("");
      }
    });
};

exports.cosmetics = function (req, res) {
  items.find({type : "cosmetics"}).then((data)=>{
    res.json(data)
  })
};

exports.items = function (req, res) {
  items.find().then((data)=>{
    res.json(data);
  })
};

exports.search = function (req, res) {
  items.find({name : {$regex : req.body.value,$options: 'i'}}).then((data)=>{
    res.json(data)
  })
};


exports.appliances = function (req, res) {
  items.find({type : "appliances"}).then((data)=>{
    res.json(data)
  })
};

exports.clothes = function (req, res) {
  console.log("3");
  
  items.find({type : "clothes"}).then((data)=>{
    res.json(data)
  })
};

exports.item = function (req, res) {
  items.findOne({_id : req.body.id}).then((data)=>{
    res.json(data)
  })
};

exports.myitems = function (req, res) {
  let id = req.cookies.id;
  users
    .findOne({ _id: id })
    .then((data) => {
      res.json(data.items);
    });
};

exports.cart = function (req, res) {
  let id = req.cookies.id
  users.findOne({_id : id}).then((data)=>{
    res.json(data.cart)
  })
};

exports.orders = function (req, res) {
  let id = req.cookies.id
  orders.find({user_id : id}).then((data)=>{
    res.json(data)
  })
};

exports.returns = function (req, res) {
  let id = req.cookies.id
  returns.find({user_id : id}).then((data)=>{
    res.json(data)
  })
};

exports.myitem = function (req, res) {
  let id = req.cookies.id;
  let item = {
    name: req.body.name,
    price: req.body.price,
    imgLink: "../images/" + req.body.imgLink,
    type: req.body.type,
    description : req.body.description,
    stock : req.body.stock
  };
  let data = new items(item);
      data.save().then((data)=>{
        users
    .findOneAndUpdate({ _id: id }, { $push: { items: data } })
    .then(() => {
      res.json()
    });
      })
};

exports.cart_count = function (req, res) {
  let id = req.cookies.id
  users.findOne({_id : id}).then((data)=>{
    let count = 0
    data.cart.forEach((obj)=>{
      if (obj._id == req.body.id){
        count = count + 1;
      }
    })
    res.json(count)
  })
};
