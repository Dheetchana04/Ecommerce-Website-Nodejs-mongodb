let orders = require("../models/orders.js");
let returns = require("../models/returns.js");
let users = require("../models/user.js");
let items = require("../models/items.js");

exports.update_order = function (req, res) {
  orders.findOneAndDelete({_id : req.body.id},{new : true}).then((data)=>{
    res.json(data)
  })
};

exports.update_return = function (req, res) {
  returns.findOneAndDelete({_id : req.body.id},{new : true}).then((data)=>{
    res.json(data)
  })
};

exports.myitem = function (req, res) {
  let id = req.cookies.id;
  
  users
    .findOneAndUpdate({ _id: id }, { $pull: { items: {name : req.body.name} } })
    .then(() => {
      items.findOneAndDelete({_id : req.body._id}).then(()=>{
        res.json()
      })
    });
};