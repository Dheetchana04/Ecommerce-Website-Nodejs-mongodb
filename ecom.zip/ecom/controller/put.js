let users = require("../models/user.js");
let orders = require("../models/orders.js");
let returns = require("../models/returns.js");
let items = require("../models/items.js");

exports.add = function (req, res) {
  if (req.cookies.id) {
    let id = req.cookies.id;
  users
    .findOneAndUpdate({ _id: id }, { $push: { cart: req.body } }, { new: true })
    .then((data) => {
      res.json(data);
    });
  }
  else {
    res.json(null);
  }
};

exports.remove = function (req, res) {
  let id = req.cookies.id;
  users
    .findOneAndUpdate({ _id: id }, { $pull: { cart: req.body } }, { new: true })
    .then((data) => {
      res.json(data);
    });
};

exports.clear = function (req, res) {
  let id = req.cookies.id;
  users
    .findOneAndUpdate({ _id: id }, { $set: { cart: [] } }, { new: true })
    .then((data) => {
      res.json(data);
    });
};

exports.order = function (req, res) {
  items.findOneAndUpdate({_id : req.body.item._id},{$inc : {stock : -1}}).then(()=>{
    let body = {
      user_id: req.cookies.id,
      address: req.cookies.address,
      item: req.body.item,
    };
    let data = new orders(body);
    data.save();
    res.json(null);
  })
};

exports.return = function (req, res) {
  items.findOneAndUpdate(req.body.item,{$inc : {stock : 1}}).then(()=>{
  let body = {
    user_id: req.cookies.id,
    address: req.cookies.address,
    item: req.body.item,
  };
  let data = new returns(body);
  data.save();
  res.json(null);
})
};