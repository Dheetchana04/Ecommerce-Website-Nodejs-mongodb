exports.home = function (req,res) {
    res.redirect("/views/home.html")
}

exports.signin = function (req,res) {
    res.redirect("/views/signin.html")
}
exports.signup = function (req,res) {
    res.redirect("/views/signup.html")
}

exports.cart = function (req,res) {
    res.redirect("/views/cart.html");
}

exports.orders = function (req,res) {
    res.redirect("/views/orders.html")
}

exports.myitems = function (req,res) {
    res.redirect("/views/myitems.html")
}